import { ref } from "vue";

const heatmapPoints = ref([])

export {heatmapPoints}