<template>
  <main class="contenido">
    <div class="header">
      <div class="fixedHeader">
        <label class="logo-container" @click="scrollTop">
          <img class="logo" src="/logo.svg" />
          <div id="logo-name">
            <div id="name"></div>
            <div id="lastName"></div>
          </div>
        </label>

        <div class="buttons">
          <button id="GITHUB" @click="linkTo($event)">GITHUB</button>
          <button id="LINKEDIN" @click="linkTo($event)">LINKEDIN</button>
          <button v-if="!heatmapOn.value" id="HEATMAP" @click="enableHeatmap">HEATMAP</button>
          <button v-if="heatmapOn.value" id="HEATMAP" @click="clearHeatmap">CLEAR HEATMAP</button>
        </div>
      </div>
    </div>

    <div class="body">
      <section class="welcome-wrapper">
        <Welcome />
      </section>

      <div>
        <section id="aboutMe">
          <AboutMe />
        </section>
        <div class="imgCarousel"></div>
      </div>

      <section id="heatmapSection">
        <div id="heatmap-container">
          <AppsSection />
        </div>
      </section>

      <section id="workWithMeSection">
        <div class="workWithMe"></div>
      </section>
    </div>
  </main>
</template>

<script>
import AppsSection from "./components/AppsSection.vue";
import Welcome from "./components/Welcome.vue";
import AboutMe from "./components/AboutMe.vue";
import { heatmapPoints } from "./store/store.js";
import { ref } from "vue";

import Heatmap from "heatmap.js";

export default {
  name: "App",
  components: {
    Welcome,
    AppsSection,
    AboutMe,
  },

  data() {
    this.heatmapOn = ref(false)
  },

  methods: {
    fixedHeader() {
      const contenido = document.querySelector(".body");
      const header = document.querySelector(".fixedHeader");
      const buttonsDiv = document.querySelector(".buttons");
      const buttons = document.querySelectorAll(".buttons button");
      const logo = document.querySelector(".logo");
      const logoFirstName = document.querySelector("#name");
      const logoLastName = document.querySelector("#lastName");

      var height = contenido.getBoundingClientRect().top;

      //console.log("height: ", height);
      var headerBackgroundColor = "rgba(0,0,0,1)";
      headerBackgroundColor = "#2c3e50";

      if (-height > 50) {
        if (header.style.backgroundColor != headerBackgroundColor) {
          header.style.backgroundColor = headerBackgroundColor;
          header.style.paddingTop = "0.5rem";
          header.style.borderBottom = "1px solid #98e8cd";
          buttonsDiv.style.gap = "1rem";

          buttons.forEach((button) => {
            button.style.height = "2rem";
            button.style.width = "5rem";
            //button.innerHTML= ''
          });

          logo.style.height = "2rem";

          logoFirstName.innerHTML = "Nicolas";
          logoFirstName.style.color = "white";

          logoLastName.innerHTML = "Martinez";
          logoLastName.style.color = "#98e8cd";
        }
      } else {
        header.style.backgroundColor = null;
        header.style.paddingTop = "1rem";
        header.style.borderBottom = "none";

        buttons.forEach((button) => {
          button.style.height = "3rem";
          button.style.width = "10rem";
          //button.innerHTML= button.id
        });

        logo.style.height = "3rem";

        logoFirstName.innerHTML = "Nicolas";
        logoFirstName.style.color = "rgba(0, 0, 0, 0)";

        logoLastName.innerHTML = "Martinez";
        logoLastName.style.color = "rgba(0, 0, 0, 0)";
        buttonsDiv.style.gap = "2rem";
      }
    },

    scrollTop() {
      window.scrollTo({ top: 0, behavior: "smooth" });
    },

    linkTo(event) {
      if (event.target.id == "GITHUB") {
        window.open("https://github.com/neekoh15", "_blank");
      } else if (event.target.id == "LINKEDIN") {
        window.open("https://linkedin.com/nmartinez93", "_blank");
      }
    },

    enableHeatmap() {
      this.heatmapOn.value = true
      //console.log('this.heatmapOn: ', this.heatmapOn.value)
      const container = document.querySelector(".contenido");
      const heatmapInstance = Heatmap.create({
        container: container,
        radius: 70,
      });

      heatmapInstance.setData({ max: 5, data: heatmapPoints.value });

      heatmapPoints.value = [];
    },

    clearHeatmap() {
      [...document.getElementsByClassName("heatmap-canvas")].forEach((e) =>
        e.remove()
      );

      this.heatmapOn.value = false
    },
  },

  mounted() {
    window.addEventListener("scroll", this.fixedHeader);

    console.log('this.heatmapOn: ', this.heatmapOn.value)

    window.onmousemove = function (ev) {
      const point = {
        x: ev.clientX + window.scrollX,
        y: ev.clientY + window.scrollY,
        value: 1,
      };

      if (heatmapPoints.value.length > 1000) {
        heatmapPoints.value.shift();
      }
      heatmapPoints.value.push(point);
    };
  },
};
</script>

<style>
* {
  margin: 0;
  padding-top: 0;
}

html {
  scroll-behavior: smooth;
  height: 100%;
}

#app {
  font-family: Helvetica, Arial, sans-serif;
  font-family: "Hagrid-Regular";
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin: 0;
  padding: 0;
  color: white;

  background-image: url("/public/background.png");
  background-size: 90%;
  background-repeat: repeat;
  animation: desplazamientoFondo 50s ease-in-out infinite alternate;
  font-size: 17px;
}

.logo-container {
  display: flex;
  align-items: center;
  flex-direction: row;
  gap: 0.3rem;
}

#logo-name {
  display: flex;
  flex-direction: row;
  gap: 0.3rem;
}

#logo-name {
  cursor: pointer;
}

a {
  line-height: 3rem;
  padding: 0;
  text-decoration: none;
  font-weight: 300 !important;
  font-size: 14px;
  font-family: "Hagrid-Regular";
  display: flex;
  height: 3rem;

  width: 10rem;
  border: 1px solid #98e8cd;
  background: none;
  color: #98e8cd;
  border-radius: 1.5rem;

  text-decoration: none;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
}

@keyframes desplazamientoFondo {
  0% {
    background-position-y: 0;
  }
  100% {
    background-position-y: 100%;
  }
}

@keyframes desplazamiendoHorizontal {
  0% {
    background-position-x: 0;
  }
  100% {
    background-position-x: 100%;
  }
}

.logo {
  transition: height 1s;
}

.logo:hover {
  cursor: pointer;
}

#name {
  transition: color 1s;
}

#lastName {
  transition: color 1s;
}

section {
  position: relative;
  display: flex;
  flex-direction: column;
  border: 1px solid rgba(100, 100, 100, 0.1);
  margin-right: 7%;
  margin-left: 7%;
  text-align: left;
  scroll-behavior: smooth;
  z-index: 1;
}

header {
  box-sizing: border-box;
}

.fixedHeader {
  position: fixed;
  width: 100%;
  box-sizing: border-box;
  display: flex;
  justify-content: space-between;
  padding-top: 1rem;
  padding-bottom: 0.5rem;
  align-items: center;
  transition: background-color 1s, padding 1s;
  padding-left: 7%;
  padding-right: 7%;
  z-index: 10;
}

.fixedHeader .buttons {
  display: flex;
  gap: 2rem;
  transition: gap 1s;
}

.buttons button {
  height: 3rem;
  width: 10rem;
  border: 1px solid #98e8cd;
  background: none;
  color: #98e8cd;
  border-radius: 1.5rem;
  transition: height 1s, width 1s, font-size 1s;
}

.buttons button:hover {
  cursor: pointer;
}

.body {
  padding-top: 15%;
  display: flex;
  flex-direction: column;
  gap: 10rem;
}

body {
}
/*
.imgCarousel {
  position: absolute;
  width: 100vw;
  height: 50%;
  background-image: url('/public/codeCarousel.png');
}/*/
#heatmap-container {
  width: 100%;
  height: 100%;
}

#heatmapSection {
  padding-top: 5rem;
}

h1 {
  font-size: 60px !important;
}
h2 {
  font-size: 30px;
}

.contenido {
  width: 100%;
  height: 100%;
  z-index: 1;
}

@font-face {
  font-family: "Hagrid-Regular";
  src: url("/public/hagrid/Hagrid-Regular-trial.ttf") format("truetype");
}

@font-face {
  font-family: "Hagrid-Italic";
  src: url("/public/hagrid/Hagrid-Italic-trial.ttf") format("truetype");
}

@font-face {
  font-family: "Hagrid-Text-Extrabold";
  src: url("/public/hagrid/Hagrid-Text-Extrabold-trial.ttf") format("truetype");
}

@font-face {
  font-family: "Hagrid-Text-Extrabold-Italic";
  src: url("/public/hagrid/Hagrid-Text-Extrabold-Italic-trial.ttf")
    format("truetype");
}
</style>
